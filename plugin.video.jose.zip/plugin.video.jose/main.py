import os
import sys
import re
import json
import urllib.request
import urllib.error
from urllib.parse import urlencode, parse_qsl
import xbmc
import xbmcgui
import xbmcplugin
from xbmcaddon import Addon
from xbmcvfs import translatePath

URL = sys.argv[0]
HANDLE = int(sys.argv[1])
ADDON_PATH = translatePath(Addon().getAddonInfo('path'))
ICONS_DIR = os.path.join(ADDON_PATH, 'resources', 'images', 'icons')
FANART_DIR = os.path.join(ADDON_PATH, 'resources', 'images', 'fanart')

ACCESS_CODE = "1234"

def obtener_canales_entretenimiento():
    return [
        {
            "title": "[COLOR green]-- CANALES M+ --[/COLOR]",
            "url": "",
            "poster": "https://i.ibb.co/gWMRpFB/vamos.png",
            "plot": "asd",
            "year": 2024,
        },
        {
            "title": "M+ Accion HD",
            "url": "plugin://script.module.horus?action=play&id=14767834db41c572ab83b80f7eadc3ba78a2ced0",
            "poster": "https://raw.githubusercontent.com/davidmuma/picons_dobleM/master/icon/M%2B%20Acci%C3%B3n.png",
            "plot": "MOVISTAR Accion FHD por Tronoss",
            "year": 2024,
        },
        # {
        #     "title": "M+ Accion 2 HD",
        #     "url": "plugin://script.module.horus?action=play&id=63ab9528b16e536be0da44d6f5aceac357292b95",
        #     "poster": "https://i.ibb.co/3NSfJbY/xmovistar-estrenos-2.jpg",
        #     "plot": "MOVISTAR Accion 2 FHD por Tronoss",
        #     "year": 2024,
        # },
        {
            "title": "M+ Hits HD",
            "url": "plugin://script.module.horus?action=play&id=b16127ba49c5065b877cb2d4073f2a4bb9a1ddbe",
            "poster": "https://raw.githubusercontent.com/davidmuma/picons_dobleM/master/icon/M%2B%20Hits.png",
            "plot": "#VAMOS FHD por Tronoss",
            "year": 2024,
        },
        {
            "title": "M+ Clásicos HD",
            "url": "plugin://script.module.horus?action=play&id=26c63851b7a0de9efed907571b19d342fc8d6765",
            "poster": "https://raw.githubusercontent.com/davidmuma/picons_dobleM/master/icon/M%2B%20Cl%C3%A1sicos.png",
            "plot": "MOVISTAR CLASICOS FHD por Tronoss",
            "year": 2024,
        },
        {
            "title": "M+ Series HD",
            "url": "plugin://script.module.horus?action=play&id=14767834db41c572ab83b80f7eadc3ba78a2ced0",
            "poster": "https://www.lyngsat-logo.com/logo/tv/mm/mplus-series-es.svg",
            "plot": "MOVISTAR SERIES POR TRONOSS",
            "year": 2024,
        },
    ]


# Lista de canales personalizados
def obtener_canales_personalizados():
    return [
        {
            "title": "[COLOR green]-- CANALES SEPARADOS --[/COLOR]",
            "url": "plugin://script.module.horus?action=play&id=6d949579bc230abff933d5ac242961319bbebc4b",
            "poster": "https://i.ibb.co/gWMRpFB/vamos.png",
            "plot": "asd",
            "year": 2024,
        },
        {
            "title": "M+ Vamos HD",
            "url": "plugin://script.module.horus?action=play&id=6d949579bc230abff933d5ac242961319bbebc4b",
            "poster": "https://i.ibb.co/gWMRpFB/vamos.png",
            "plot": "#VAMOS FHD 2 por Tronoss",
            "year": 2024,
        },
        {
            "title": "M+ Vamos HD",
            "url": "plugin://script.module.horus?action=play&id=b16127ba49c5065b877cb2d4073f2a4bb9a1ddbe",
            "poster": "https://i.ibb.co/gWMRpFB/vamos.png",
            "plot": "#VAMOS FHD por Tronoss",
            "year": 2024,
        },
        {
            "title": "DAZN 1 BAR",
            "url": "plugin://script.module.horus?action=play&id=0908f5dd264ded10b638636cb7479409cfee0813",
            "poster": "https://raw.githubusercontent.com/davidmuma/picons_dobleM/master/icon/DAZN%201%20BAR.png",
            "plot": "DAZN 1 BAR FHD por Tronoss",
            "year": 2024,
        },
        {
            "title": "DAZN 1 HD",
            "url": "plugin://script.module.horus?action=play&id=e6121426f7d8007ae9de8e782f05d91e9b27993d",
            "poster": "https://i.ibb.co/FVzKq1y/dazn1.png",
            "plot": "DAZN 1 BAR FHD por Tronoss",
            "year": 2024,
        },
    ]

def obtener_canales():
    url = "https://elcano.top"
    headers = {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) Chrome/115.0 Safari/537.36"
    }
    try:
        req = urllib.request.Request(url, headers=headers)
        with urllib.request.urlopen(req, timeout=10) as response:
            html = response.read().decode("utf-8")
        regex = r'const\s+linksData\s*=\s*(\{.*?\})\s*;'
        match = re.search(regex, html, re.DOTALL)
        if not match:
            return []
        data = json.loads(match.group(1))
        canales = [
            {
                "title": canal.get("name", "Sin Nombre"),
                "url": canal.get("url", ""),
                "poster": "https://upload.wikimedia.org/wikipedia/commons/thumb/8/83/Acestream_logo.svg/512px-Acestream_logo.svg.png",
                "plot": "Canal en vivo: " + canal.get("name", "Sin Nombre"),
                "year": 2024,
            }
            for canal in data.get("links", [])
            if canal.get("url", "").startswith("acestream://")
        ]
        return canales
    except:
        return []

VIDEOS = [
    {
        'genre': '[COLOR green]+[/COLOR] DEPORTES',
        'icon': os.path.join(ICONS_DIR, 'movistar.jpg'),
        'fanart': os.path.join(FANART_DIR, 'Movistar-deportes.jpg'),
        'movies': obtener_canales() + obtener_canales_personalizados(),
    },
    {
        'genre': '[COLOR green]+[/COLOR] DEPORTES',
        'icon': os.path.join(ICONS_DIR, 'movistar.jpg'),
        'fanart': os.path.join(FANART_DIR, 'Movistar-deportes.jpg'),
        'movies': obtener_canales_entretenimiento(),
    }
]

def get_url(**kwargs):
    return '{}?{}'.format(URL, urlencode(kwargs))

def show_code_screen():
    keyboard = xbmcgui.Dialog().input("Introduce el código de acceso")
    if keyboard == ACCESS_CODE:
        list_genres()
    else:
        show_code_screen()

def list_genres():
    xbmcplugin.setPluginCategory(HANDLE, 'Public Domain Movies')
    xbmcplugin.setContent(HANDLE, 'movies')
    for index, genre in enumerate(VIDEOS):
        list_item = xbmcgui.ListItem(label=genre['genre'])
        list_item.setArt({'icon': genre['icon'], 'fanart': genre['fanart']})
        url = get_url(action='listing', genre_index=index)
        xbmcplugin.addDirectoryItem(HANDLE, url, list_item, True)
    xbmcplugin.endOfDirectory(HANDLE)

def list_videos(genre_index):
    genre_info = VIDEOS[genre_index]
    xbmcplugin.setPluginCategory(HANDLE, genre_info['genre'])
    xbmcplugin.setContent(HANDLE, 'movies')
    for video in genre_info['movies']:
        list_item = xbmcgui.ListItem(label=video['title'])
        list_item.setArt({'poster': video['poster']})
        list_item.setInfo('video', {
            'title': video['title'],
            'genre': genre_info['genre'],
            'plot': video['plot'],
            'year': video['year']
        })
        list_item.setProperty('IsPlayable', 'true')
        url = get_url(action='play', video=video['url'])
        xbmcplugin.addDirectoryItem(HANDLE, url, list_item, False)
    xbmcplugin.endOfDirectory(HANDLE)

def play_video(path):
    if path.startswith("acestream://"):
        stream_id = path[len("acestream://"):]
        new_path = "plugin://script.module.horus?action=play&id=" + stream_id
    else:
        new_path = path
    list_item = xbmcgui.ListItem(path=new_path)
    xbmcplugin.setResolvedUrl(HANDLE, True, list_item)

params = dict(parse_qsl(sys.argv[2][1:]))
action = params.get('action')

if action is None:
    show_code_screen()
elif action == 'listing':
    list_videos(int(params['genre_index']))
elif action == 'play':
    play_video(params['video'])
